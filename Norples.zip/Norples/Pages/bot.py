import streamlit as st
import base64

def get_base64(bin_file):
    try:
        with open(bin_file, 'rb') as f:
            data = f.read()
        return base64.b64encode(data).decode()
    except FileNotFoundError:
        return ""

def apply_bot_ui():
    norple_face = get_base64('Norpleface.svg')
    norple_sitting = get_base64('Norplesitting.png')

    st.markdown(f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;700;900&display=swap');

    html, body, [class*="css"], .stApp {{
        font-family: 'Poppins', sans-serif !important;
        background-color: #EBEBEB !important;
    }}

    header, footer, #MainMenu {{visibility: hidden;}}

    .home-btn {{
        position: absolute;
        top: 25px;
        left: 25px;
        width: 50px;
        z-index: 1000;
        cursor: pointer;
        transition: transform 0.3s ease;
    }}
    .home-btn:hover {{ transform: scale(1.1); }}

    .hero-container {{
        display: flex; 
        justify-content: center;
        width: 100%; 
        margin-top: 10px;
        padding-left: 180px; 
    }}
    .sitting-norple {{ 
        width: 340px; 
    }}

    div[data-testid="stTextArea"] {{
        margin-top: 20px !important;
        max-width: 800px !important;
        margin-left: auto !important;
        margin-right: auto !important;
    }}
    
    div[data-testid="stTextArea"] [data-testid="InputInstructions"] {{
        display: none !important;
    }}

    div[data-testid="stTextArea"] > div {{
        background-color: transparent !important;
        border: 4px solid #1A1A1A !important;
        border-radius: 40px !important;
        box-shadow: none !important;
    }}

    div[data-testid="stTextArea"] textarea {{
        background-color: transparent !important;
        border: none !important;
        text-align: left !important;
        letter-spacing: normal !important;
        text-transform: none !important;
        color: #1A1A1A !important;
        font-size: 18px !important;
        padding: 15px 30px !important;
        line-height: 1.5 !important;
        min-height: 60px !important;
        max-height: 200px !important;
        resize: none !important;
        overflow: hidden !important; 
    }}

    div[data-testid="stTextArea"] textarea:focus {{
        overflow-y: auto !important;
    }}

    div[data-testid="stTextArea"] textarea::-webkit-scrollbar {{
        width: 6px;
    }}
    div[data-testid="stTextArea"] textarea::-webkit-scrollbar-thumb {{
        background-color: #1A1A1A;
        border-radius: 10px;
    }}
    div[data-testid="stTextArea"] textarea::-webkit-scrollbar-track {{
        background: transparent;
    }}

    .stFileUploader section {{
        background-color: transparent !important;
        border: 4px solid #1A1A1A !important;
        border-radius: 40px !important;
        height: 180px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        padding: 0 !important;
    }}
    
    .stFileUploader label, 
    .stFileUploader section > div, 
    .stFileUploader section > small,
    .stFileUploader section span {{
        display: none !important;
    }}

    .size-limit-label {{
        font-size: 10px;
        color: #888;
        text-align: center;
        margin-top: 15px;
        letter-spacing: 1px;
        display: block;
        width: 100%;
    }}

    .overlay-card {{
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 180px;
        pointer-events: none;
        margin-top: -180px;
    }}

    button {{
        background-color: #E6E1E6 !important;
        border: 4px solid #1A1A1A !important;
        border-radius: 40px !important;
        height: 180px !important;
        width: 100% !important;
        font-size: 60px !important;
        color: #1A1A1A !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        transition: 0.2s ease;
    }}
    button:hover {{ background-color: #DED6DE !important; }}
    </style>

    <a href="/">
        <img src="data:image/svg+xml;base64,{norple_face}" class="home-btn">
    </a>
    <div class="hero-container">
        <img src="data:image/png;base64,{norple_sitting}" class="sitting-norple">
    </div>
    """, unsafe_allow_html=True)

st.set_page_config(page_title="NORPLE", layout="wide")

if 'slots' not in st.session_state:
    st.session_state.slots = 3

apply_bot_ui()

_, main_col, _ = st.columns([1, 8, 1])

with main_col:
    st.text_area("", placeholder="Type Here", label_visibility="collapsed", height=60)

    st.write('<div style="margin-top: 60px;">', unsafe_allow_html=True)
    cols = st.columns(5)
    
    for i in range(st.session_state.slots):
        with cols[i]:
            uploaded_file = st.file_uploader("", key=f"up_{i}")
            
            if uploaded_file is None:
                st.markdown(f'''
                    <div class="overlay-card">
                        <p style="font-size:10px; letter-spacing:2px;">ATTACH HERE</p>
                    </div>
                    <span class="size-limit-label">200MB per file</span>
                ''', unsafe_allow_html=True)
            else:
                st.markdown(f'''
                    <div class="overlay-card">
                        <p style="font-size:11px; font-weight:600; text-align:center; padding: 0 10px;">{uploaded_file.name[:12]}...</p>
                        <p style="font-size:20px; margin-top:10px;">✅</p>
                    </div>
                    <span class="size-limit-label">Uploaded</span>
                ''', unsafe_allow_html=True)

    if st.session_state.slots < 5:
        with cols[st.session_state.slots]:
            if st.button("+"):
                st.session_state.slots += 1
                st.rerun()
    st.write('</div>', unsafe_allow_html=True)