import streamlit as st
import base64

# --- UTILITY FUNCTIONS ---
def get_base64(bin_file):
    """Convert binary file to base64 string for CSS injection."""
    try:
        with open(bin_file, 'rb') as f:
            data = f.read()
        return base64.b64encode(data).decode()
    except FileNotFoundError:
        return ""

def apply_minimalist_ui():
    """Injects CSS for the main landing page."""
    norple_svg = get_base64('NORPLE.svg')
    softworks_png = get_base64('Softworks.png')

    st.markdown(f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;700;900&display=swap');

    html, body, [class*="css"], .stApp {{
        font-family: 'Poppins', sans-serif !important;
        background-color: #EBEBEB !important;
    }}

    header, footer, #MainMenu {{visibility: hidden;}}

    .hero-wrapper {{
        display: flex;
        flex-direction: column;
        align-items: center; 
        justify-content: center;
        text-align: center;
        width: 100%;
        padding-top: 140px;
    }}

    .introducing {{
        font-weight: 400;
        font-size: 16px;
        letter-spacing: 15px; 
        color: #1A1A1A;
        text-transform: uppercase;
        margin-bottom: 25px; 
    }}

    .main-logo-img {{
        width: 580px;
        margin-bottom: 70px; 
    }}

    .powered-container {{
        margin-bottom: 45px;
    }}

    .powered-text {{
        font-weight: 400;
        font-size: 10px;
        letter-spacing: 5px;
        color: #888;
        margin-bottom: 10px;
        text-transform: uppercase;
    }}

    .soft-logo-img {{
        width: 100px;
    }}

    /* Perfect Centering for the Button */
    [data-testid="stVerticalBlock"] > div:has(div.stButton) {{
        display: flex !important;
        justify-content: center !important;
        width: 100% !important;
    }}

    .stButton {{
        display: flex !important;
        justify-content: center !important;
    }}

    .stButton > button {{
        background-color: #1A1A1A !important;
        color: white !important;
        border-radius: 100px !important;
        padding: 12px 60px !important;
        font-family: 'Poppins', sans-serif !important;
        font-weight: 700 !important;
        font-size: 16px !important;
        letter-spacing: 3px !important;
        border: none !important;
        margin: 0 auto !important;
        min-width: 220px !important;
        transition: all 0.3s ease;
    }}

    .status-text {{
        font-family: 'Poppins', sans-serif !important;
        color: #888888;
        font-size: 12px;
        text-align: center;
        margin-top: 15px;
        display: block;
    }}
    </style>
    
    <div class="hero-wrapper">
        <p class="introducing">INTRODUCING</p>
        <img src="data:image/svg+xml;base64,{norple_svg}" class="main-logo-img">
        <div class="powered-container">
            <p class="powered-text">POWERED BY</p>
            <img src="data:image/png;base64,{softworks_png}" class="soft-logo-img">
        </div>
    </div>
    """, unsafe_allow_html=True)

st.set_page_config(page_title="NORPLE", layout="wide")
apply_minimalist_ui()

if st.button("GET STARTED"):
    st.markdown('<p class="status-text">Navigating to AI Bot...</p>', unsafe_allow_html=True)
    st.switch_page("pages/bot.py")